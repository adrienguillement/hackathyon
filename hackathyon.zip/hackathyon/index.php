<?php
header('location:./pages/');

